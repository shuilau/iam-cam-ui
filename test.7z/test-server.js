// eslint-disable-next-line import/no-extraneous-dependencies
const express = require('express');

const app = express();
const port = 3001;

app.use(express.static('./dist'));
app.use('/cam', express.static('./dist')); 

app.get('/', (req, res) => {
  res.send('Hello World!');
});

app.listen(port, () => {
  // eslint-disable-next-line no-console
  console.log(`Test server listening on port ${port}`);
});
