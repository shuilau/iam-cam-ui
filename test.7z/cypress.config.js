const { defineConfig } = require('cypress')

module.exports = defineConfig({
  defaultCommandTimeout: 10000,
  projectId: '446e32',
  chromeWebSecurity: false,
  reporter: 'junit',
  reporterOptions: {
    mochaFile: './out/test/test-output-[hash].xml',
  },
  numTestsKeptInMemory: 0,
  video: false,
  screenshotOnRunFailure: false,
  retries: 2,
  e2e: {
    // We've imported your old cypress plugins here.
    // You may want to clean this up later by importing these.
    setupNodeEvents(on, config) {
      return require('./cypress/plugins/index.js')(on, config)
    },
    baseUrl: 'http://localhost:3001',
    specPattern: 'cypress/e2e/**/*.{js,jsx,ts,tsx}',
  },
})
