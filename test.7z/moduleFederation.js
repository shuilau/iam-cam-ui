const packageJson = require('./package.json');
const deps = packageJson.dependencies;

module.exports = {
  name: packageJson.name,
  filename: 'remoteEntry.js',
  library: {
    type: 'window',
    name: packageJson.name,
  },
  exposes: {
    './RolesTable': './src/feature/components/RolesTable/index',
    './RolesPage': './src/feature/pages/Roles/index',
    './CamApp': './src/App',
    './types': './src/types',
  },
  shared: {
    react: { singleton: true, eager: true, requiredVersion: deps.react },
    'react-dom': { singleton: true, eager: true, requiredVersion: deps["react-dom"] }
  },
}
