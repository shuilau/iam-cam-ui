const { ModuleFederationPlugin } = require('webpack').container;
const CopyWebpackPlugin = require('copy-webpack-plugin');
const { NativeFederationTypeScriptRemote } = require('@module-federation/native-federation-typescript/webpack');
const { NativeFederationTestsRemote } = require('@module-federation/native-federation-tests/webpack');
const path = require('path');
const moduleFederationConfig = require('./moduleFederation');
const packageJson = require('./package.json');
const packageJsonName = packageJson.name;
const scope = packageJsonName.split('/')[0];
const name = packageJsonName.split('/')[1];

module.exports = function override(config, env) {
  if (process.env.BUILD_ENV === "test") {
    // "react-app-rewired" seems to replace process.env.BABEL_ENV with "production" even when we set it to "test" in the npm scripts.
    // So, we are using custom environmnet variable "BUILD_ENV" instead, and programagically setting the BABEL_ENV based on the value of BUILD_ENV
    process.env.BABEL_ENV = 'test'
  }
  const isProduction = config.mode === 'production';

  config = {
    ...config,
    devtool: isProduction ? undefined : config.devtool,
    devServer: {
      liveReload: true,
      watchFiles: [path.resolve(__dirname, 'src')],
      open: true,
      headers: {
        'Access-Control-Allow-Origin': '*',
      },
      disableHostCheck: true,
      allowedHosts: ['.pcc-labs.com'],
      host: process.env.HOST,
      port: 8080,
    },
    entry: {
      main: './src/mfe.ts',
      [`${packageJson.name}`]: './src/microfrontends/index.ts',
    },
    output: {
      ...config.output,
      publicPath: '/cam/',
    }
  };

  config.module.rules.push({
    test: /\.(js|jsx|ts|tsx)$/,
    use: {
      loader: 'babel-loader',
      options: {
        presets: [
          '@babel/preset-env',
          ['@babel/preset-react', { runtime: 'automatic' }],
          '@babel/preset-typescript'
        ],
        plugins: ['@babel/plugin-transform-runtime'],
      },
    },
    exclude: /node_modules/,
  });

  const index = config.plugins.findIndex(plugin => plugin.constructor.name === 'DefinePlugin');
  config.plugins[index].definitions = {
    ...config.plugins[index].definitions,
    'process.env.npm_package_name': `"${packageJson.name}"`
  };

  config.plugins = [
    ...config.plugins,
    new ModuleFederationPlugin(moduleFederationConfig),
    new CopyWebpackPlugin({
      patterns: [
        {
          from: isProduction ? './src/assets/moduleConfig-prod.json' : './src/assets/moduleConfig-dev.json',
          to: 'static/js/moduleConfig.json'
        },
        {
          from: isProduction ? './src/assets/moduleConfig-prod.json' : './src/assets/moduleConfig-dev.json',
          to: 'moduleConfig.json'
        },
      ],
    }),
    NativeFederationTypeScriptRemote({ moduleFederationConfig, typesFolder: `${scope}-${name}-types`, compiledTypesFolder: '.' }),
    NativeFederationTestsRemote({ moduleFederationConfig, distFolder: './dist', testsFolder: `${scope}-${name}-tests`, additionalBundlerConfig: { format: 'esm' } }),
  ];

  return config;
};