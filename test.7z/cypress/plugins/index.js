// ***********************************************************
// This example plugins/index.js can be used to load plugins
//
// You can change the location of this file or turn off loading
// the plugins file with the 'pluginsFile' configuration option.
//
// You can read more here:
// https://on.cypress.io/plugins-guide
// ***********************************************************

const webpackPreprocessor = require('@cypress/webpack-preprocessor');
const webpack = require('webpack');
const path = require('path');

function resolve(dir) {
  return path.join(__dirname, '../..', dir);
}

module.exports = (on, config) => {
  // Code coverage and logs printer
  require('@cypress/code-coverage/task')(on, config);
  require('cypress-terminal-report/src/installLogsPrinter')(on);

  // Webpack preprocessor for Cypress
  const options = {
    webpackOptions: {
      module: {
        rules: [
          {
            test: /\.(js|jsx|ts|tsx)$/,
            use: {
              loader: 'babel-loader',
              options: {
                presets: [
                  '@babel/preset-env',
                  ['@babel/preset-react', { runtime: 'automatic' }],
                  '@babel/preset-typescript'
                ],
                plugins: [
                  '@babel/plugin-transform-runtime'
                ]
              }
            },
            exclude: /node_modules/
          }
        ]
      },
      resolve: {
        fallback: {
          url: require.resolve('url'),
          crypto: require.resolve('crypto-browserify'),
          stream: require.resolve('stream-browserify'),
          vm: require.resolve('vm-browserify'),
          buffer: require.resolve('buffer'),
          path: require.resolve('path-browserify'),
        }
      },
      plugins: [
        new webpack.ProvidePlugin({
          React: 'react',
          dayjs: [resolve('src/plugins/dayjs.js'), 'default'],
          process: 'process/browser',
          Buffer: ['buffer', 'Buffer']
        }),
        new webpack.DefinePlugin({
          'process.version': `"${process.version}"`
        })
      ]
    }
  };

  on('file:preprocessor', webpackPreprocessor(options));

  // Chrome-specific settings for garbage collection
  on('before:browser:launch', (browser = {}, launchOptions) => {
    if (browser.name === 'chrome') {
      launchOptions.args.push('--js-flags=--expose-gc');
    }
    return launchOptions;
  });

  // IMPORTANT: return the config object with any changed environment variables
  return config;
};
