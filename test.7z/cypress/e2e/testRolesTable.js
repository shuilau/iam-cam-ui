
 
describe('RolesTable Component', () => {
    
    beforeEach(() => {
        
        cy.intercept('GET', '**/api/roles*', { fixture: 'roles.json' }).as('getRoles');
        cy.intercept('GET', '**/api/permissions/role/*', { fixture: 'permissions.json' }).as('getPermissions');
        cy.setUpServer();
        cy.visit('/');
    });
    


    it('should display the roles table with row data', () => {
            cy.get('[data-testid=roles-table]').should('be.visible');
            cy.contains("Accounting and Finance Staff").should('be.visible');
    });

    it('should scroll down roles table by changing rows per page', () => {
        cy.get('[data-testid=roles-table]').should('be.visible');
        cy.contains("Accounting and Finance Staff").should('be.visible');
        cy.get('div[role="button"]').first().click({force:true});
        cy.contains('li','25').click();
        cy.get('.__PCC_EVERGREEN_table-list__').scrollTo('bottom');

    });
    

    it('should open permissions dialog when Manage button is clicked', () => {
        cy.get('[data-testid=roles-table]').should('be.visible');
        cy.get('[data-testid=roles-table]').within(() => {
            cy.get('button[aria-label="managePermissions"]').first().click();
            }
        );
        cy.get('[data-testid=permission-table]').should('be.visible');
    });
    

    it('should close permissions dialog when cancel button is clicked ', () => {
        cy.get('[data-testid=roles-table]').should('be.visible');
        cy.get('[data-testid=roles-table]').within(() => {
            cy.get('button[aria-label="managePermissions"]').first().click();
            }
        );
        cy.get('[data-testid=permission-table]').should('be.visible');
        cy.get('[data-testid=cancel-button').first().click();

    });
          
 
    
});
