describe('PermissionTable Component', () => {

    beforeEach(() => {
        cy.intercept('GET', '**/api/permissions/role/*', { fixture: 'permissions.json' }).as('getPermissions');
        cy.intercept('GET', '**/api/roles*', { fixture: 'roles.json' }).as('getRoles');
        cy.intercept('POST', '**/api/permissions/role/*',{statusCode: 200, body:''}).as('savePermissions');
        cy.setUpServer();
        cy.visit('/');
        
        cy.get('[data-testid=roles-table]').within(() => {
            cy.get('button[aria-label="managePermissions"]').first().click();
            }
        );
    });

    it('should display the permission table with data', () => {
        cy.get('[data-testid=permission-table]').should('be.visible');
        cy.contains("Payers").should('be.visible'); 
    });

    it('should allow changing access level in edit mode', () => {
        cy.get('[data-testid=edit-button]').click();
        cy.get('[data-testid=permission-select]').first().should('contain', 'Viewer'); 
        cy.get('div[role="button"]#custom-select').first().click({force:true});
        
        cy.contains('li','Creator').click();
        cy.get('[data-testid=permission-select]').first().should('contain', 'Creator'); 


    });

    it('should display permissions in the dropdown', () => {
        cy.get('[data-testid=edit-button]').click();
        cy.get('div[role="button"]#custom-select').first().click({force:true});
        cy.get('li[data-value]').should('have.length', 5);
        cy.get('li.MuiMenuItem-root').eq(0).should('contain', 'No Access');
        cy.get('li.MuiMenuItem-root').eq(1).should('contain', 'Viewer');
        cy.get('li.MuiMenuItem-root').eq(2).should('contain', 'Creator');
        cy.get('li.MuiMenuItem-root').eq(3).should('contain', 'Editor');
        cy.get('li.MuiMenuItem-root').eq(4).should('contain', 'Full Access');
    });
    


    it('should show Save Snackbar when clicked on Save button', () => {
        cy.get('[data-testid=edit-button]').click();
        cy.get('[data-testid=permission-select]').first().should('contain', 'Viewer'); 
        cy.get('div[role="button"]#custom-select').first().click({force:true});
        
        cy.contains('li','Creator').click();
        cy.get('[data-testid=permission-select]').first().should('contain', 'Creator'); 
        cy.get('[data-testid=save-button]').click();
        cy.contains('Standard role access updated successfully.').should('be.visible');
        cy.contains('Manage Standard Role Access').should('not.exist');

    });

    it('should show Cancel Confirmation dialog when clicked on Cancel button while editing', () => {
        cy.get('[data-testid=edit-button]').click();
        cy.get('[data-testid=cancel-button').first().click();
        cy.contains('This standard role has unsaved changes. The changes will be discarded.').should('be.visible');

    });


    it('should close Cancel Confirmation dialog when clicked on Discard Changes', () => {
        cy.get('[data-testid=edit-button]').click();
        cy.get('[data-testid=cancel-button').first().click();
        cy.contains('This standard role has unsaved changes. The changes will be discarded.').should('be.visible');
        cy.get('[data-testid=discard-button').click();
        cy.contains('This standard role has unsaved changes. The changes will be discarded.').should('not.be.visible');

    });

    it('should be able to keep editing when clicked on Keep Editing', () => {
        cy.get('[data-testid=edit-button]').click();
        cy.get('[data-testid=cancel-button]').first().click();
        cy.contains('This standard role has unsaved changes. The changes will be discarded.').should('be.visible');
        cy.get('[data-testid=keep-editing]').click();
        cy.contains('This standard role has unsaved changes. The changes will be discarded.').should('not.be.visible');
        cy.get('[data-testid=permission-select]').first().should('contain', 'Viewer'); 
        cy.get('div[role="button"]#custom-select').first().click({force:true});
        
        cy.contains('li','Creator').click();
        cy.get('[data-testid=permission-select]').first().should('contain', 'Creator'); 

    });

    it('should open Error Dialog when clicked on Save button with error response', () => {
        cy.intercept('POST', '**/api/permissions/role/*',{statusCode: 500, body:''}).as('savePermissions');
        cy.get('[data-testid=edit-button]').click();
        cy.get('[data-testid=permission-select]').first().should('contain', 'Viewer'); 
        cy.get('div[role="button"]#custom-select').first().click({force:true});
        
        cy.contains('li','Creator').click();
        cy.get('[data-testid=permission-select]').first().should('contain', 'Creator'); 
        cy.get('[data-testid=save-button]').click();
        cy.contains('Unable to save standard role access. Please try again.').should('be.visible');

    });

});
