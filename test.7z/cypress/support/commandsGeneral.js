/* eslint-disable no-undef */
Cypress.Commands.add(
  'setUpServer',
  (
    sessionStatus,
    aeResponse
  ) => {
    cy.server();

    cy.fixture('usersMe').then((responseBody) => {
      cy.route({
        method: 'GET',
        url: 'api/users/me',
        response: aeResponse || responseBody,
        status: sessionStatus || 200,
      }).as('usersMeApiCall');
    });
    
  },
);
