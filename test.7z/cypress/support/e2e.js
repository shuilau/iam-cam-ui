import './commandsGeneral';
import '@cypress/code-coverage/support';