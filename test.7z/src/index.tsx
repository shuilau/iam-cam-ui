import React from 'react';
import ReactDOM from 'react-dom';
import { datadogRum } from '@datadog/browser-rum';

import { App } from './App'

import './index.css';

const environment = (function getEnvName() {
  return process.env.NODE_ENV;
}());

if (environment && environment !== 'development') {
  datadogRum.init({
    applicationId: '52f246ec-4be4-439d-8efe-41a2a67549da',
  clientToken: 'pub58da09d102328c331cfda40a6187474f',
  // `site` refers to the Datadog site parameter of your organization
  // see https://docs.datadoghq.com/getting_started/site/
  site: 'datadoghq.com',
  service: 'iam-cam-ui',
  env: environment,
  // Specify a version number to identify the deployed version of your application in Datadog
  // version: '1.0.0', 
  sessionSampleRate: 2,
  sessionReplaySampleRate: 1,
  trackUserInteractions: true,
  trackResources: true,
  trackLongTasks: true,
  defaultPrivacyLevel: 'mask-user-input',
  });
} else {
  datadogRum.init({
    applicationId: 'd842a13b-23b8-45a5-82b5-51547faf9332',
    clientToken: 'pub6ca3821a37786916f3873c5db1125b7f',
    // `site` refers to the Datadog site parameter of your organization
    // see https://docs.datadoghq.com/getting_started/site/
    site: 'datadoghq.com',
    service: 'iam-cam-ui',
    env: 'development',
    sampleRate: 100,
    useCrossSiteSessionCookie: true,
    trackInteractions: false,
  });
}

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root'),
);
