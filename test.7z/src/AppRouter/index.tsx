import { Suspense } from 'react'
import { HashRouter as Router, Route, Switch } from 'react-router-dom'
import { Header } from '@evergreen/core'

import { NotFound } from '../feature/pages/NotFound'
import { lazily } from '../utils/lazily'

import { useStyles } from './styles'

const { RolesPage }: { RolesPage: () => JSX.Element } = lazily(() => import('../feature/pages/Roles'))

const TITLE = 'Common Access Management'

export const AppRouter = (): JSX.Element => {
  const style = useStyles()

  return (
    <Router basename="/">
      <div className={style.root}>
        <Header headerText={TITLE} />
        <main className={style.main}>
          <Suspense fallback={<div>Loading...</div>}>
            <Switch>
              <Route exact path="/" component={RolesPage} />
              <Route exact path="*">
                <NotFound />
              </Route>

              <Route path="/404" component={NotFound} />
            </Switch>
          </Suspense>
          <div />
        </main>
      </div>
    </Router>
  )
}
