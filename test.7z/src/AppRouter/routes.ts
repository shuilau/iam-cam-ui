// Route config file
import { RouteProps } from 'react-router-dom'
import type { Route } from '@evergreen/core'
import InboxIcon from '@material-ui/icons/Inbox'
export const ROLES_PATH = '/roles'

export const routes: Route<RouteProps>[] = [
  {
    path: ROLES_PATH,
    label: 'Roles',
    icon: InboxIcon,
  },
]
