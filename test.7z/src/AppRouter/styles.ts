import { createStyles, makeStyles, Theme } from '@material-ui/core'

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      display: 'flex',
      marginTop: `${theme.spacing(9)}px`,
    },
    main: {
      display: 'flex',
      flexGrow: 1,
      overflowX: 'auto',
      padding: `${theme.spacing(1)}px`,
      backgroundColor: theme.palette.background.default,
      height: `calc(100vh - ${theme.spacing(9)}px)`,
    },
  }),
)

export { useStyles }
