import axios from 'axios'
import {PermissionModel, RolesModel} from "./types";

const apiCall = axios.create({
    baseURL: "/api",
    headers: {
        "Content-Type": "application/json",
    },
})

export const IamService = {
    getRoles: async (orgId: string): Promise<Array<RolesModel>> => {
        const result: Array<RolesModel> = [];
        const response =
            await apiCall.get(`/roles?organizationId=${orgId}`, {
                    headers: {Accept: 'application/json'},
                }
            )
        if (response.data) {
            if (response.data.length > 0) {
                response.data.forEach((item: any) => {
                    const role: RolesModel = {
                        displayName: item.displayName,
                        description: item.description,
                        name: item.name,
                        products: item.products.map((product: any) => product.name).join(', ')
                    };
                    result.push(role);
                });
            }
        }
        return result;
    },
    getPermissions: async (roleName: string): Promise<Array<PermissionModel>> => {
        const result: Array<PermissionModel> = [];
        const response =
            await apiCall.get(`/permissions/role/${roleName}`, {
                    headers: {Accept: 'application/json'},
                }
            )
        if (response.data) {
            response.data.permissions.forEach((item: any) => {

                const permission: PermissionModel = {
                    permissionCode: item.permissionCode,
                    grantedAccessLevel: item.grantedAccessLevel,
                    permissionDisplayName: item.permissionDisplayName,
                    permissionTypeDisplayName: item.permissionTypeDisplayName,
                    isEditable: item.isEditable
                };
                result.push(permission);
            });

        }
        return result;
    },
    getUserOrgId: async (): Promise<string> => {
        let orgId: string = '';
        const response =
            await apiCall.get('/users/me', {
                    headers: {Accept: 'application/json'},
                }
            )
        if (response.data) {
            const isPccAmin = response.data.pccAdmin;
            if (isPccAmin) {
                orgId = response.data.tenantId;
            } else {
                orgId = response.data.userOrgId;
            }
        }
        return orgId;
    },
    updatePermissions: async (roleName: string, permissions: Array<PermissionModel>): Promise<void> => {
        await apiCall.post(`/permissions/role/${roleName}`, {
                permissions: permissions.map((permission) => {
                    return {
                        permissionCode: permission.permissionCode,
                        grantedAccessLevel: permission.grantedAccessLevel,

                    };
                }),
            }
        )
    }
}