/* eslint-disable camelcase */
type RolesModel = {
    displayName: string;
    description: string;
    products: string;
    name: string;
};


type PermissionModel = {
    permissionCode: string;
    grantedAccessLevel: number;
    permissionDisplayName: string;
    permissionTypeDisplayName: string;
    isEditable: boolean;
};

export type {RolesModel, PermissionModel}
