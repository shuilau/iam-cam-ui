import { RolesTable } from './feature/components/RolesTable'
import { RolesPage } from './feature/pages/Roles'
import { App as CamApp } from './App'

const remoteComponents = { RolesTable, RolesPage, CamApp }
export declare type RemoteComponents = typeof remoteComponents
