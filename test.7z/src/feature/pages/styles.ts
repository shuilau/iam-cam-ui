import {createStyles, makeStyles, Theme} from '@material-ui/core'

const usePageStyles = makeStyles((_theme: Theme) =>
    createStyles({
        page: {
            flex: '1 1 0px',
            position: 'relative',
            display: 'flex',
            flexDirection: 'column',
            marginLeft: 24,
            marginRight: 24,
        },
        loader: {
            position: 'absolute',
            top: '0px',
            bottom: '0px',
            left: '0px',
            right: '0px',
            margin: 'auto',
        },
    })
)

export {usePageStyles}
