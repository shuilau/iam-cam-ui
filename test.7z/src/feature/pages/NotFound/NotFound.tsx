import { Typography } from '@material-ui/core'

function NotFound(): JSX.Element {
  return <Typography variant="h1">Page Not Found</Typography>
}

export default NotFound
