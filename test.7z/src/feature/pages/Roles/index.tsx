import {Typography} from '@evergreen/core'
import {Paper} from '@material-ui/core'
import {QueryClient, QueryClientProvider} from '@tanstack/react-query'

import {createWebComponent} from '../../../microfrontends/components'
import {RolesTable} from '../../components/RolesTable'
import {usePageStyles} from '../styles'

import {useStyles} from './styles'

function RolesPage() {
    const classes = useStyles()
    const pageStyles = usePageStyles()

    return (
        <>
            <Typography className={classes.title} variant="h1">
                Standard Role Configuration
            </Typography>
            <Paper className={pageStyles.page}>
                <div data-testid="roles-table-container">
                    <RolesTable />
                </div>
            </Paper>
        </>
    );
}

export {RolesPage}

const RolesPageWithQueryProvider = () => (
    <QueryClientProvider client={new QueryClient()}>
        <RolesPage />
    </QueryClientProvider>
);

createWebComponent(RolesPageWithQueryProvider, 'RolesPage');
