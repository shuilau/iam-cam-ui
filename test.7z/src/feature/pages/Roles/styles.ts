import { createStyles, makeStyles } from '@material-ui/core/styles';
import {theme} from "@evergreen/core";

const useStyles = makeStyles(() =>
    createStyles({
        '@global': {
            '*::-webkit-scrollbar': {
                backgroundColor: '#fff',
                width: 16
            },
            '*::-webkit-scrollbar-track': {
                backgroundColor: '#fff'
            },
            '*::-webkit-scrollbar-thumb': {
                backgroundColor: '#babac0',
                borderRadius: 16,
                border: '4px solid #fff',
                minHeight: 48
            },
            '*::-webkit-scrollbar-button': {
                display: 'none'
            },
            /* Firefox only */
            '*': {
                scrollbarWidth: 'thin'
            },
            '.v-application p': {
                marginBottom: '2px'            
            }
        },
        title: {
            margin: `${theme.spacing(3)}px`,
        },
        text: {
            font: 'Roboto',
            weight: 400,
            size: '16px',
            maxWidth: 'unset',
            paddingTop: 10,
            paddingBottom: 20
        },
        addGroupBtnDiv: {
            paddingLeft: 0.5
        },
        addGroupBtn: {
            marginTop: 10,
            marginBottom: 2
        },
        root: {
            '& [role="table"] [role="row"] [data-column-id="__actions__"] > *': {
                visibility: 'hidden',
                pointerEvents: 'none'
            },
            '& [role="table"] [role="row"]:hover [data-column-id="__actions__"] > *':
                {
                    visibility: 'visible',
                    pointerEvents: 'auto'
                },
            width: '100%',
            height: 'calc(100vh - 50rem)',
            overflowX: 'hidden', 
            '& [role="rowgroup"]:first-child': {
                borderRight: '1px solid rgba(0, 0, 0, 0.12)'
            }
        }
    })
);

export { useStyles }
