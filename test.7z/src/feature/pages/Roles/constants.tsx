/* eslint-disable no-console */
import { ReactNode } from 'react'
import {OverflowTextTooltip, TableCell, TableColumn, Typography} from '@evergreen/core'

import { RolesModel } from '../../../common/service/types'

export const columns: TableColumn<RolesModel>[] = [
    {
        id: 'role_name',
        accessor: 'displayName',
        Header: 'Standard Role',
        disableResizing: true,
        width: Math.round((window.innerWidth - 55) * 0.2),
    },
    {
        id: 'role_description',
        accessor: 'description',
        Header: 'Description',
        width: Math.round((window.innerWidth - 55) * 0.4),
        disableResizing: true,
        Cell({ cell }: TableCell<RolesModel>): ReactNode {
            return (
                <OverflowTextTooltip title={cell.row.original.description}>
                    <Typography>{cell.row.original.description}</Typography>
                </OverflowTextTooltip>
            );
        },
    },
    {
        id: 'products',
        accessor: 'products',
        Header: 'Products',
        width: Math.round((window.innerWidth - 55) * 0.15),
        disableResizing: true,
        Cell({ cell }: TableCell<RolesModel>): ReactNode {
            return (
                <OverflowTextTooltip title={cell.row.original.products}>
                    <Typography>{cell.row.original.products}</Typography>
                </OverflowTextTooltip>
            );
        },
    }
];
