import React, {useEffect, useState} from 'react';
import {CardContent} from '@material-ui/core';
import { ErrorDialogProps } from './types';
import {Button, Dialog, Typography} from '@evergreen/core';
import {ErrorRounded} from "@material-ui/icons";

const ErrorDialog = ({
                                   open,title, message
                              }: ErrorDialogProps) => {
    const [dialogOpen, setDialogOpen] = useState(open);

    useEffect(() => {
        setDialogOpen(open);
    }, [open]);

    const handleClose = () => {
        setDialogOpen(false);
    };

    const actions = (
       
            <Button
                color="primary"
                data-testid="cancel-button"
                label='Close'
                onClick={handleClose}
                variant="contained"
            />
       
    );

    const content = (
        <>
            <div style={{display:'flex', alignContent: 'left', padding: '0'}}>
                <ErrorRounded htmlColor='red' style={{marginRight: '8px'}}/>
                <Typography variant="h1">
                    {title}
                </Typography>
            </div>
            <div style={{marginBottom: '1rem',width: 'inherit'}}>
                    <CardContent>
                        <Typography style={{whiteSpace: 'nowrap'}}>
                            {message}
                        </Typography>
                    </CardContent>
            </div>
        </>
    );
    return (
        <>
            
                <Dialog
                    open={dialogOpen}
                    actions={actions}
                    onClose={handleClose}
                    content={content}
                />
           
        </>

    );
};

export default ErrorDialog;