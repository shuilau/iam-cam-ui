export interface ErrorDialogProps {
    open: boolean;
    title: string;
    message: string;
}
