import {Table, TableRowAction} from '@evergreen/core'
import {API_STATUS} from '@evergreen/hooks-use-api'

import {IamService} from '../../../common/service'
import {columns} from '../../pages/Roles/constants'
import React, {useCallback, useEffect, useState} from "react";
import {RolesModel} from "../../../common/service/types";
import useStyles from './styles';
import PermissionDialog from "../PermissionDialog";

export const RolesTable = () => {
    const classes = useStyles({});

    const [openPermissionsDialog, setOpenPermissionsDialog] =
        useState<boolean>(false);
    const [selectedRowData, setSelectedRowData] = useState<RolesModel | null>(null);
    const [resultSet, setResultSet] = useState<RolesModel[]>([]);
    const [status, setStatus] = useState<API_STATUS>(API_STATUS.LOADING);
    const handleManageClick = useCallback((row) => {
        setOpenPermissionsDialog(true);
        setSelectedRowData(row); // Assuming 'row' contains the data of the clicked row
    }, []);

    const handleDialogClose = useCallback(() => {
        setOpenPermissionsDialog(false);
    }, []);

    useEffect(() => {
        IamService.getUserOrgId().then((orgId) => {
            IamService.getRoles(orgId).then((result) => {
                setResultSet(result);
                setStatus(API_STATUS.COMPLETED);
            })
        })

    }, []);

    const rowActions: TableRowAction<any>[] = [
        {
            id: 'managePermissions',
            label: 'Manage',
            onClick: handleManageClick,
        }
    ];
    const pageableProps = {
        pageSize: 10,
    };

    return (
        <>
            <div className={classes.root}>
                <Table
                    variant="client-side"
                    columns={columns}
                    data={resultSet}
                    loadingStatus={status}
                    rowActions={rowActions}
                    data-testid="roles-table"
                    pageable
                    pageableProps={pageableProps}
                    title={'You can manage standard role access and add users to standard roles.'}
                />
            </div>
            <PermissionDialog
                openPermissionsDialog={openPermissionsDialog}
                data={selectedRowData!}
                handlePermissionDialogClose={handleDialogClose}
                data-testid="permission-dialog"
            />
        </>
    )
}

export default RolesTable;
