import {createStyles, makeStyles} from '@material-ui/core/styles';

const useStyles = makeStyles(() =>
    createStyles({
        '@global': {
            '*::-webkit-scrollbar': {
                backgroundColor: '#fff',
                width: 16
            },
            '*::-webkit-scrollbar-track': {
                backgroundColor: '#fff'
            },
            '*::-webkit-scrollbar-thumb': {
                backgroundColor: '#babac0',
                borderRadius: 16,
                border: '4px solid #fff',
                minHeight: 48
            },
            '*::-webkit-scrollbar-button': {
                display: 'none'
            },
            /* Firefox only */
            '*': {
                scrollbarWidth: 'hidden'
            }
        },
        text: {
            font: 'Roboto',
            weight: 400,
            size: '16px',
            maxWidth: 'unset',
            paddingTop: 10,
            paddingBottom: 20
        },
        root: {
            width: '100%',
            height: 'calc(100vh - 20rem)',
            overflowX: 'hidden', 
            '& [role="rowgroup"]:first-child': {
                borderRight: '1px solid rgba(0, 0, 0, 0.12)'
            }
        },
    })
);
export default useStyles;
