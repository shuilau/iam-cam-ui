import {TableCell} from "@evergreen/core";
import {PermissionModel} from "../../../common/service/types";

export interface PermissionSelectProps {
    cellData?: TableCell<PermissionModel>;
    onValueChange: (permissionCode: string, newValue: number) => void;
}

export const crudPermissions = [
    {value: 0, primary: 'No Access', secondary: 'User has no access.'},
    {value: 1, primary: 'Viewer', secondary: 'User can view only.'},
    {value: 2, primary: 'Creator', secondary: 'User can read and add.'},
    {value: 3, primary: 'Editor', secondary: 'User can read, add, and edit.'},
    {value: 4, primary: 'Full Access', secondary: 'User can read, add, edit, and delete.'},
];
