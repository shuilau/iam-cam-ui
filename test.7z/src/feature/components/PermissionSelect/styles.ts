import {createStyles, makeStyles} from '@material-ui/core/styles';

const useStyles = makeStyles(() =>
    createStyles({
        selectRoot: {
            display: 'flex',
            alignItems: 'center',
        },
        select: {
            padding: '10px 14px',
        },
        menuItem: {
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'flex-start',
            whiteSpace: 'normal',
        }
    })
);

export default useStyles;
