import React, {useEffect, useState} from 'react';
import {TextField, MenuItem, ListItemText} from '@material-ui/core';
import {crudPermissions, PermissionSelectProps} from "./type";
import useStyles from './styles';

const PermissionSelect = ({
                              cellData,
                              onValueChange
                          }: PermissionSelectProps) => {
    const classes = useStyles();
    const [selectedValue, setSelectedValue] = useState<number | ''>(cellData?.value || '');

    useEffect(() => {
        setSelectedValue(cellData?.value || '');
    }, [cellData?.value]);

    const handleChange = (event: React.ChangeEvent<{ value: unknown }>) => {
        const newValue = Number(event.target.value);
        setSelectedValue(newValue);
        onValueChange(cellData.row.original.permissionCode, newValue);
    };

    const renderValue = (val: unknown) => {
        const selectedOption = crudPermissions.find(selectValue => selectValue.value === Number(val));
        return selectedOption ? selectedOption.primary : '';
    };

    return (
        <>
            <TextField
                key={`${cellData?.row.id}-${selectedValue}`} // Dynamic key based on selectedValue
                id="custom-select"
                select
                fullWidth
                label="Access"
                value={selectedValue}
                onChange={handleChange}
                margin="dense"
                variant="outlined"
                SelectProps={{
                    displayEmpty: true,
                    renderValue: renderValue as (val: unknown) => string,
                    classes: {root: classes.selectRoot, select: classes.select}
                }}
                InputLabelProps={{shrink: true}}
                data-testid="permission-select"
            >
                {crudPermissions.map((selectValue) => (
                    <MenuItem value={selectValue.value} key={selectValue.primary} className={classes.menuItem}>
                        <ListItemText primary={selectValue.primary} secondary={selectValue.secondary}/>
                    </MenuItem>
                ))}
            </TextField>
        </>
    );
};

export default PermissionSelect;
