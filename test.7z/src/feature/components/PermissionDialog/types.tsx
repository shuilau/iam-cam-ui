import {RolesModel} from "../../../common/service/types";

export interface PermissionsDialogProps {
    openPermissionsDialog: boolean;
    data: RolesModel;
    handlePermissionDialogClose: () => void;
}
