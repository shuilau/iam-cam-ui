import {createStyles, makeStyles} from '@material-ui/core/styles';

const useStyles = makeStyles(() =>
    createStyles({
        permissionLabel: {
            marginBottom: 5
        },
        dialogTitle: {
            alignContent: 'left',
            paddingLeft: 0
        }
    })
);

export default useStyles;
