import React, {useState, useEffect, useCallback} from 'react';
import {Button, Dialog, Typography} from '@evergreen/core';
import {PermissionsDialogProps} from "./types";
import {PermissionTable} from "../PermissionTable";
import {Edit} from "@material-ui/icons";
import useStyles from './styles';
import {IamService} from "../../../common/service";
import SnackbarNotification from "../SnackbarNotification";
import {Card, CardContent, DialogTitle} from '@material-ui/core';
import ErrorDialog from '../ErrorDialog';


const PermissionDialog = ({
                              openPermissionsDialog,
                              data,
                              handlePermissionDialogClose
                          }: PermissionsDialogProps) => {
    const classes = useStyles({});

    const [openPermissions, setOpenPermissions] = useState(false);
    const [updatedTableData, setUpdatedTableData] = useState([]);
    const [isVisible, setIsVisible] = useState(true);
    const [isEditMode, setIsEditMode] = useState(false);
    const [snackbarOpen, setSnackbarOpen] = useState(false);
    const [snackbarKey, setSnackbarKey] = useState(Date.now());
    const [snackbarMessage, setSnackbarMessage] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const [snackbarError, setSnackbarError] = useState(false);
    const [openConfirmation, setOpenConfirmation] = useState(false);
    const [errorTitle, setErrorTitle] = useState('');
    const [errorDialogOpen, setErrorDialogOpen] = useState(false);


    const handleEditButton = () => {
        setIsVisible(false);
        setIsEditMode(true)
    }

    const handleEditReset = () => {
        setIsVisible(true);
        setIsEditMode(false)
    }

    useEffect(() => {
        setOpenPermissions(openPermissionsDialog!);
    }, [openPermissionsDialog]);

    const handleTableDataChange = useCallback((newData) => {
        setUpdatedTableData(newData);
    }, []);

    const resetAndShowSnackbar = () => {
        setSnackbarOpen(false);
        // Force a re-render with a new key to remount the SnackbarNotification
        setSnackbarKey(Date.now());
        setSnackbarOpen(true);
    };

    const handleCloseConfirmation = () => {
        setOpenConfirmation(false);
        handleOnCancel();
    };

    const handleOpenConfirmation = () => {
        if(isEditMode){
            setOpenConfirmation(true);
        }else{
            handleOnCancel()
        }
    }

    const handleKeepEditing = ()  => {
        setOpenConfirmation(false);
    }

    const handleSave = () => {
        IamService.updatePermissions(data.name, updatedTableData)
            .then(() => {
                setOpenPermissions(false);
                handleEditReset();
                if (handlePermissionDialogClose) {
                    handlePermissionDialogClose();
                }
                setSnackbarError(false);
                setSnackbarMessage('Standard role access updated successfully.');
                resetAndShowSnackbar();
            })
            .catch(error => {
                console.log('Error updating permissions', error);
                setErrorDialogOpen(true);
                setErrorTitle("Error Saving")
                setErrorMessage("Unable to save standard role access. Please try again.");
            });
    };

    const handleOnCancel = useCallback(() => {
        if (handlePermissionDialogClose) {
            handlePermissionDialogClose();
        }
        handleEditReset();
    }, [handlePermissionDialogClose]);


    const actions = (
        <>
            <Button
                color="primary"
                data-testid="save-button"
                label='Save'
                disabled={!isEditMode}
                onClick={handleSave}
                variant="contained"
            />
            <Button
                color="primary"
                data-testid="cancel-button"
                label='Cancel'
                onClick={handleOpenConfirmation}
                variant="outlined"
            />
        </>
    );

    const content = (
        <>
            <DialogTitle className={classes.dialogTitle}>
                <Typography variant="h2">
                    Manage Standard Role Access
                </Typography>
            </DialogTitle>
            <div style={{marginBottom: '1rem',width: 'inherit'}}>
                <Card>
                    <CardContent>
                        <Typography variant="body1" className={classes.permissionLabel}>
                            {data?.displayName}
                        </Typography>
                        <Typography
                            fullWidth
                            variant="body2">
                            {data?.description}
                        </Typography>
                    </CardContent>
                </Card>
            </div>
            {isVisible && updatedTableData.length > 0 && (
                <div style={{display: 'flex', alignItems: 'center', justifyContent: 'space-between'}}>
                    <Typography variant="body1">
                        Click the edit icon to update access.
                    </Typography>
                    <Button
                        color="secondary"
                        data-testid="edit-button"
                        onClick={handleEditButton}
                        variant="icon">
                        <Edit/>
                    </Button>
                </div>
            )}
            <div style={{width: '101.5%'}}>
                <PermissionTable rowData={data} onTableDataChange={handleTableDataChange} isEditMode={isEditMode}/>
            </div>
        </>
    );

    const confirmationContent = (
        <>
            <DialogTitle className={classes.dialogTitle}>
                <Typography variant="h2">
                    Discard Changes
                </Typography>
            </DialogTitle>
            <div style={{marginBottom: '1rem',width: 'inherit'}}>
                    <CardContent>
                        <Typography style={{whiteSpace: 'nowrap'}}>
                            This standard role has unsaved changes. The changes will be discarded. 
                        </Typography>
                    </CardContent>
            </div>
        </>
    );

    const confirmActions = (
        <>
            <Button
                color="primary"
                data-testid="discard-button"
                label='Discard Changes'
                disabled={!isEditMode}
                onClick={handleCloseConfirmation}
                variant="contained"
            />
            <Button
                color="primary"
                data-testid="keep-editing"
                label='Keep Editing'
                onClick={handleKeepEditing}
                variant="outlined"
            />
        </>
    );

    return (
        <>
            <Dialog
                scroll="body"
                actions={actions}
                content={content}
                open={openPermissions}
                maxWidth="md"
                data-testid="permission-dialog"
            />
            <Dialog
                scroll="body"
                actions={confirmActions}
                content={confirmationContent}
                open={openConfirmation}
                maxWidth="md"
                data-testid="permission-dialog"
            />
            <SnackbarNotification
                snackbarKey={snackbarKey}
                open={snackbarOpen}
                message={snackbarMessage}
                isError={snackbarError}
                data-testid="snackbar-notification"
            />
            <ErrorDialog
                open={errorDialogOpen}
                title={errorTitle}
                message={errorMessage}
            />
        </>
    );
};


export default PermissionDialog;




