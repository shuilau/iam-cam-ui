import {PermissionModel, RolesModel} from "../../../common/service/types";
import {OptionProps} from "@evergreen/core";

export const radioOptionsWithLabels: OptionProps[] = [
    {
        id: 'yes-item',
        label: 'Yes',
        value: '1',
    },
    {
        id: 'no-item',
        label: 'No',
        value: '0',
    }
];

export interface PermissionTableProps {
    rowData?: RolesModel;
    onTableDataChange?: (newData: PermissionModel[]) => void;
    isEditMode?: boolean;

}

export const booleanPermissions = [
    {value: 0, primary: 'No ', secondary: 'User has no access.'},
    {value: 1, primary: 'Yes', secondary: 'User can view only.'}
];
