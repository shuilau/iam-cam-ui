import {useQuery} from "@tanstack/react-query";
import {IamService} from "../../../common/service";

import {API_STATUS} from "@evergreen/hooks-use-api";

import {PermissionTableProps, radioOptionsWithLabels} from "./types";
import {PermissionModel, RolesModel} from "../../../common/service/types";
import SelectionControl from '@evergreen/core-selection-control';

import {
    RenderDirection,
    SelectionControlType,
    Table, TableCell, TableColumn, Typography
} from "@evergreen/core";
import React, {ReactNode, useEffect, useState} from "react";
import PermissionSelect from "../PermissionSelect";
import {crudPermissions} from "../PermissionSelect/type";

export const PermissionTable = ({rowData, onTableDataChange, isEditMode}: PermissionTableProps) => {
    const {isLoading, isError, data} = useQuery({
        queryKey: ['iamPermissions'],
        queryFn: () => IamService.getPermissions(rowData?.name || ''),
        refetchOnWindowFocus: false
    });


    useEffect(() => {
        if (data) {
            setTableData(data);
            onTableDataChange && onTableDataChange(data); // Invoke on initial load
        }
    }, [data, onTableDataChange]); // Include onTableDataChange in dependency array to handle prop changes

    const [tableData, setTableData] = useState<PermissionModel[]>([]);

    const handleSelectChange = (permissionCode: string, newValue: number) => {
        setTableData((currentTableData) => {
            const updatedTableData = currentTableData.map((permission) => {
                if (permission.permissionCode === permissionCode) {
                    return {...permission, grantedAccessLevel: newValue};
                }
                return permission;
            });
            onTableDataChange && onTableDataChange(updatedTableData); // Invoke on data update
            return updatedTableData;
        });
    };

    const status = isLoading ? API_STATUS.LOADING : isError ? API_STATUS.ERROR : API_STATUS.COMPLETED;

    const columns: TableColumn<PermissionModel>[] = [
        {
            id: 'permissionDisplayName',
            accessor: 'permissionDisplayName',
            Header: 'Feature',
            width: 400,
            Cell({cell}: TableCell<RolesModel>): ReactNode {
                return (
                    <Typography>{cell.row.original.permissionDisplayName}</Typography>
                );
            },
        },
        {
            id: 'permissionName',
            accessor: 'grantedAccessLevel',
            Header: 'Access',
            width: 400,
            Cell(cell: TableCell<PermissionModel>): ReactNode {
                if (isEditMode && cell.row.original.isEditable) {
                    return (
                        <>
                            {cell.row.original.permissionTypeDisplayName === 'Crud' ? (
                                <PermissionSelect
                                    cellData={cell}
                                    data-testid="permission-select"
                                    onValueChange={(permissionCode, newValue) => handleSelectChange(permissionCode, newValue)}
                                />
                            ) : (
                                <div style={{ paddingLeft: '10px' }}> 
                                    <SelectionControl
                                        data-testid="permission-select"
                                        type={SelectionControlType.Radio}
                                        options={radioOptionsWithLabels}
                                        defaultValue={cell.row.original.grantedAccessLevel.toString()}
                                        renderDirection={RenderDirection.Horizontal}
                                        onChange={(e) => handleSelectChange(cell.row.original.permissionCode, parseInt((e.target as HTMLInputElement).value))}
                                    />
                                </div>
                            )}
                        </>
                    );
                } else {
                    const displayValue = cell.row.original.permissionTypeDisplayName === 'Crud' ?
                        crudPermissions.find(p => p.value === cell.value)?.primary :
                        radioOptionsWithLabels.find(option => option.value.toString() === cell.value.toString())?.label;
        
                    return <Typography>{displayValue}</Typography>;
                }
            }
        }
        
    ];

    return (
        <>
            <div style={{width: '100%', height: 'calc(100vh - 30rem)'}}>
                <Table
                    data-testid="permission-table"
                    variant="client-side"
                    columns={columns}
                    data={tableData}
                    loadingStatus={status}
                    hasBorder
                />
            </div>
        </>

    );
};

export default PermissionTable;
