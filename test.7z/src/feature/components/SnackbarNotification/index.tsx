import React, {useEffect, useState} from 'react';

import {Snackbar} from '@material-ui/core';
import {SnackbarNotificationProps} from "./type";
import {Alert} from "@material-ui/lab";

const SnackbarNotification = ({
                                  snackbarKey, open, message, isError
                              }: SnackbarNotificationProps) => {
    const [snackbarOpen, setSnackbarOpen] = useState(open);

    useEffect(() => {
        setSnackbarOpen(open);
    }, [open]);

    const handleClose = () => {
        setSnackbarOpen(false);
    };
    return (
        <>
            {isError ? (
                <Snackbar
                    open={snackbarOpen}
                    autoHideDuration={5000}
                    onClose={handleClose}
                    key={snackbarKey}
                >
                    <Alert onClose={handleClose} severity="error">
                        {message}
                    </Alert>
                </Snackbar>
            ) : (
                <Snackbar
                    open={snackbarOpen}
                    autoHideDuration={5000}
                    onClose={handleClose}
                    message={message}
                    key={snackbarKey}
                />
            )}
        </>

    );
};

export default SnackbarNotification;
