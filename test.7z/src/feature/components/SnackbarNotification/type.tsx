export interface SnackbarNotificationProps {
    snackbarKey: number;
    open: boolean;
    message: string;
    isError: boolean;
}
