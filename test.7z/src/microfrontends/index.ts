
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore-next-line
import { loadModuleConfig } from '@pointclickcare-mfe/microfrontends/esm/config'
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const SCRIPT = (document?.currentScript as any)?.src ?? ''
const MODULE_CONFIG_FILE = `${SCRIPT.substring(0, SCRIPT.lastIndexOf('/'))}/moduleConfig.json`
export const MODULE_CONFIG = loadModuleConfig(MODULE_CONFIG_FILE)

export {}
