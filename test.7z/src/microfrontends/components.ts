import { FunctionComponent } from 'react'
import { theme as EvergreenTheme } from '@evergreen/core'
import { asyncFunction, createWebComponent as mfeCreateWebComponent, lazyComponent, lazyWebComponent } from '@pointclickcare-mfe/microfrontends'

import { MODULE_CONFIG } from '.'

export const importFunction = <T extends Record<string, unknown>>(module: string): T => asyncFunction(module, MODULE_CONFIG)
export const importComponent = <T extends Record<string, unknown>>(module: string): T => lazyComponent(module, MODULE_CONFIG)
export const importWebComponent = <T extends Record<string, unknown>>(module: string): T => lazyWebComponent(module, MODULE_CONFIG)

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const createWebComponent = async (Component: FunctionComponent<any>, componentName: string, shadowDom = false, theme = true) =>
  mfeCreateWebComponent({
    Component,
    theme: theme ? EvergreenTheme : undefined,
    containerName: process.env.npm_package_name as string,
    componentName,
    shadowDom,
  })
