import { lazy } from 'react'

// eslint-disable-next-line @typescript-eslint/ban-types, @typescript-eslint/no-explicit-any
export const lazily = <T extends {}>(loader: () => Promise<any>) =>
  new Proxy({} as unknown as T, {
    get: (_target, componentName) => lazy(() => loader().then((x) => ({ default: x[componentName] }))),
  })
