/* eslint-disable import/no-extraneous-dependencies */
import React from 'react'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'

interface QueryTestProviderProps {
  children?: React.ReactNode
}

export const QueryTestProvider = ({ children }: QueryTestProviderProps): JSX.Element => (
  <QueryClientProvider client={new QueryClient({ defaultOptions: { queries: { retry: false } } })}>{children}</QueryClientProvider>
)
