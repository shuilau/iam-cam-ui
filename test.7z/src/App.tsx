
import { datadogRum } from '@datadog/browser-rum';
import { theme } from '@evergreen/core'
import { ThemeProvider } from '@material-ui/core'
import { createGenerateClassName, StylesProvider } from '@material-ui/core/styles'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { ReactQueryDevtools } from '@tanstack/react-query-devtools'

import { createWebComponent } from './microfrontends/components'
import { AppRouter } from './AppRouter';

import './App.css';

const generateClassName = createGenerateClassName({
  productionPrefix: 'react-17-cra-camui-mfe',
})

const queryClient = new QueryClient()
export function App() {

  datadogRum.addAction('clicked_on_buttom1', {
    target: '.button',
    callback: ()=>{
      console.log('button clicked')
    },
  })
  return (
    <StylesProvider generateClassName={generateClassName}>
      <ThemeProvider theme={theme}>
        <QueryClientProvider client={queryClient}>
          <AppRouter />
          <ReactQueryDevtools initialIsOpen={false} />
        </QueryClientProvider>
      </ThemeProvider>
    </StylesProvider>
  )
}


createWebComponent(App, 'CamApp')
